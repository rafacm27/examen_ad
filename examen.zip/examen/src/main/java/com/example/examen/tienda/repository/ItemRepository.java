package com.example.examen.tienda.repository;

import com.example.examen.tienda.models.Items;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface ItemRepository extends MongoRepository<Items, String> {
    List<Items> findByCategory(String category);
    List<Items> findByRateGreaterThan(double rate);
}
