package com.example.examen.tienda.controllers;

import com.example.examen.tienda.models.Items;
import com.example.examen.tienda.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/items")
public class ItemController {

    @Autowired
    private ItemRepository itemRepository;

    @PostMapping
    public Items addItem(@RequestBody Items item) {
        return itemRepository.save(item);
    }

    @DeleteMapping("/{id}")
    public void deleteItem(@PathVariable String id) {
        itemRepository.deleteById(id);
    }

    @GetMapping("/{id}")
    public Optional<Items> getItemById(@PathVariable String id) {
        return itemRepository.findById(id);
    }

    @GetMapping("/categoria/{category}")
    public List<Items> getItemsByCategory(@PathVariable String category) {
        return itemRepository.findByCategory(category);
    }

    @GetMapping("/stats")
    public String getStats(@RequestParam double minRate) {
        long totalItems = itemRepository.count();
        List<Items> highRatedItems = itemRepository.findByRateGreaterThan(minRate);

        return "Número total de ítems: " + totalItems + "\nÍtems con puntuación mayor a " + minRate + ": " + highRatedItems.size();
    }
}
